-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2017 at 07:43 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nanosoftware`
--

-- --------------------------------------------------------

--
-- Table structure for table `softwarelist`
--

CREATE TABLE `softwarelist` (
  `softwareId` varchar(10) NOT NULL,
  `category` varchar(30) NOT NULL,
  `title` varchar(100) NOT NULL,
  `imagePath` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `downloadLink` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `softwarelist`
--

INSERT INTO `softwarelist` (`softwareId`, `category`, `title`, `imagePath`, `content`, `downloadLink`) VALUES
('SG00001', 'games', 'Star Wars: The Old Republic', 'pictures/star-wars-the-old-republic-logo1317412243.jpg', 'Star Wars : The Old Republic merupakan sebuah MMORPG (massively multiplayer online role-playing games) yang berdasarkan pada universe Star Wars itu sendiri. Game ini didevelop oleh BioWare Austin dan team di BioWare Edmonton.<br>Cerita pada game ini bertepatan di universe Star Wars Legends tak lama setelah pembentukan perdamaian antara re-emergent Sith Empire dengan Galactic Republic, 300 tahun setelah peristiwa dari game Star Wars : Knight of The Old Republic.<br><br>Selain itu, game ini juga dapat didownload dan dimainkan secara gratis.', 'http://www.swtor.com/game/download'),
('SG00002', 'games', 'Counter Strike: Global Offensive', 'pictures/headecsgor.jpg', 'Counter Strike : Global Offensive adalah game dengan mode FPS (First-Person Shooter) yang dikembangkan oleh Valve Corporation dan Hidden Path Entertainment, yang juga merupakan perusahaan yang mengembangkan Counter Strike : Source . <br>\r\nGame ini dapat dimainkan pada Microsoft Windows, OS X, Xbox Live Arcade dan Playstation Network versi Amerika.<br>\r\n\r\nGame ini dapat dibeli melalui steam seharga Rp. 115.999 , - ', 'http://store.steampowered.com/app/730/'),
('SG00003', 'games', 'Dota 2', 'pictures/dotahead.jpg', 'Dota 2 merupakan sebuah permainan MOBA (multiplayer online battle arena), di mana game ini merupakan sekuel dari mod bernama Defense of The Ancients pada permainan Warcraft 3.<br>\r\nDota 2 dikembangkan oleh Valve Corporation.<br>\r\nPermainan ini dapat dimainkan secara gratis pada OS Microsoft Windows, OS X, dan Linux.', 'http://store.steampowered.com/app/570/'),
('SG00004', 'games', 'Paladins', 'pictures/paladins.jpg', 'merupakan game  First Person Shooter yang dikembangkan oleh Hi-Rez Studios', 'http://store.steampowered.com/app/444090/'),
('SG00005', 'games', 'Dota2 Broken Edition', 'pictures/dotahead.jpg', 'merupakan mod dari Dota2 yang dikembangkan oleh TEAM BROKEN', 'http://dota2.killmeplz.com'),
('SP00001', 'programming', 'Netbeans', 'pictures/imgres.jpg', 'Netbeans merupakan sebuah IDE (Integrated Development Environment) open souce berbasis Java dari Sun Microsystems untuk mengembangkan Java, C++, PHP, ataupun bahasa pemrograman yang lain.<br> \r\nNetBeans juga dapat digunakan untuk mengembangkan aplikasi Java Desktop.<br> \r\nKelebihan dari NetBeans :<br> \r\n-   NetBeans GUI Builder disediakan secara gratis dengan ribuan plug in yang tersedia untuk didownload langsung dari website resminya.<br> \r\n-   NetBeans tidak hanya dapat digunakan untuk membuat program dengan bahasa java saja, tetapi juga dapat digunakan untuk bahasa C/C++, PHP, ataupun Ruby.<br> \r\n-   NetBeans GUI Builder dapat digunakan dalam pengembangan berskala Enterprise.', 'https://netbeans.org/downloads/'),
('SP00002', 'programming', 'Dev C++', 'pictures/dev_c___by_capristo.png', 'Dev C++ merupakan sebuah IDE (Integrated Development Environment) untuk bahasa pemrograman C/C++ . Dev C++ menggunakan port Mingw dari GCC (GNU Compiler Collection).<br>\r\n\r\nBerikut fitur – fitur dari Dev C++ :<br>\r\n- Support GCC-based compilers<br>\r\n- Integrated debugging (using GDB)<br>\r\n- Project Manager<br>\r\n- Customizable syntax highlighting editor<br>\r\n- Class Browser<br>\r\n- Code Completion<br>\r\n- Function listing<br>\r\n- Profiling support<br>\r\n- Quickly create Windows, console, static libraries and DLLs<br>\r\n- Support of templates for creating your own project types<br>\r\n- Makefile creation<br>\r\n- Edit and compile Resource files<br>\r\n- Tool Manager<br>\r\n- Print support<br>\r\n- Find and replace facilities<br>\r\n- CVS support', 'http://www.bloodshed.net/download.html'),
('SP00003', 'programming', 'Sublime Text', 'pictures/Sublime_Text_Logo.png', 'Sublime Text merupakan editor berbasis Phyton yang biasa digunakan oleh para Web Developer untuk membuat atau mengembangkan website.<br>\r\nPada saat ini sublime text sudah mencapai versi ketiga (Sublime Text 3).<br>\r\nKelebihan dari Sublime Text antara lain :<br>\r\n-   Multiple Selection<br>\r\n-   Go to Line<br>\r\n-   Package Control & Themes<br>\r\n-   Emmet', 'https://www.sublimetext.com/3'),
('SP00004', 'programming', 'Eclipse', 'pictures/eclipseimage.png', 'Eclipse merupakan sebuah IDE (Integrated Development Environment) untuk mengembangkan perangkat lunak, dan dapat dijalankan di semua platform.<br>\r\nEclipse merupakan IDE open source, yang dapat didownload secara gratis.<br>\r\nKonsep Eclipse adalah terbuka, dan mudah diperluas untuk apa saja. Jadi apabila ingin digunakan untuk bermacam keperluan , cukup dengan mengistal plug-in yang dibutuhkan.', 'http://www.eclipse.org/eclipselink/downloads/'),
('SU00001', 'utilities', 'TuneUp Utilities', 'pictures/Tuneup utilities 2014-5799.png', 'TuneUp Utilities adalah perangkat lunak yang berfungsi untuk memaksimalkan kinerja Sistem Operasi pada komputer. <br>Software ini juga dapat memperbaiki registry dan menata ulang registry Windows, shingga memperkecil resiko kerusakan sistem dan mempercepat kinerjanya.<br>\r\n                Selain itu softwar ini juga dapat menghapus data pada harddisk hingga benar – benar tidak berbekas. <br>\r\n\r\n                Tools utama pada TuneUp Utilites adalah : <br>\r\n                -   Maintain system<br>\r\n                -   Increase Performance<br>\r\n                -   Fix Problems<br>\r\n                -   Customize windows', 'http://www.avg.com/ww-en/tuneup-utilities'),
('SU00002', 'utilities', 'CCleaner', 'pictures/cclueanr.jpg', ' CCleaner adalah software gratis yang digunakan untuk mengoptimalkan komputer dan membersihkan registry-nya. Salah satu fitur yang tersedia pada software ini adalah tersedianya tools untuk membersihkan cache.<br>\r\n                Utility toos ini memiliki ukuran yang sangat kecil, sehingga tidak membebani resource komputer. <br><br>\r\n\r\n                Fitur-fitur utama dari CCleaner antara lain :<br>\r\n                -   Cleaner<br>\r\n                -   Registry<br>\r\n                -   Tools<br>\r\n                -   Options', ''),
('SU00003', 'utilities', 'AVG Anti-Virus', 'pictures/AVG-Anti-Virus-Logo.png', ' AVG merupakan sebuah program antivirus yang dibuat oleh AVG Technogolies.<br>\r\n                    Keunikan-keunikan dari AVG Anti-Virus : <br>\r\n                    -   LinkScanner <br>\r\n                    -   Anti-Rootkit<br>\r\n                    <br>\r\n                    AVG juga menjediakan versi gratis untuk didownload', 'http://www.avg.com/ppc/ww-en/protection-ultimate-vs-free?dsc=4wf&d=20&h2=20&subh2=20&ECID=ad:go:se:WW-EN-Antivirus-Brand-Search&gclid=Cj0KEQiA4JnCBRDQ5be3nKCPhpwBEiQAjwN1buc7unifRrmkIu6FlnfLiJcKadJ2xDiDewVPcUKiE3AaAgwF8P8HAQ');

-- --------------------------------------------------------

--
-- Table structure for table `useraccount`
--

CREATE TABLE `useraccount` (
  `userName` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `hobby` varchar(30) DEFAULT NULL,
  `address` text,
  `phone` varchar(15) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraccount`
--

INSERT INTO `useraccount` (`userName`, `password`, `email`, `gender`, `hobby`, `address`, `phone`, `dob`, `age`) VALUES
('admin', 'admin', 'admin@nanosoftware.com', '', NULL, NULL, NULL, NULL, NULL),
('alex123', 'alex123', 'alex123@gmail.com', 'male', NULL, NULL, NULL, NULL, NULL),
('athuur123', 'athur123', 'athur123@gmail.com', 'female', 'working out', 'Jakarta Street', '23676234', '1996-08-22', 20),
('donalite123', 'donalite123', 'alken_karjono@gmail.com', 'male', NULL, NULL, NULL, NULL, NULL),
('hansetoAbreno', 'vendeta007', 'hanseto@yahoo.com', 'male', 'working out', 'Jakarta Street', '58900782', '1995-12-02', 21),
('hanson1000', 'vendeta007', 'hanson2abraham@gmail.com', 'female', 'reading a book', 'Jl. Penyelesaian Tomang II', '58900782', '1995-12-02', 21),
('hanson2000', 'vendeta007', 'hansonsuryadi@yahoo.com', 'male', NULL, 'kjabkjbfkbakwbfkj', '58900782', '1995-12-02', 21),
('hanson5000', 'vendeta009', 'hanson2abraham@gmail.com', 'male', NULL, NULL, NULL, NULL, NULL),
('hanson6000', 'vendeta007', 'hansonsuryadi@yahoo.com', 'male', NULL, NULL, NULL, NULL, NULL),
('nkakjdnkjw', 'vendeta009', 'hasbdjhab@gmail.com', 'female', NULL, NULL, NULL, NULL, NULL),
('redsmilodon2000', 'red', 'redsmil@gmail.com', 'female', 'studying', 'Pekapuran Street', '087888866939', '1995-11-20', 21);

-- --------------------------------------------------------

--
-- Table structure for table `viewcount`
--

CREATE TABLE `viewcount` (
  `viewerCount` int(50) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `viewcount`
--

INSERT INTO `viewcount` (`viewerCount`) VALUES
(2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `softwarelist`
--
ALTER TABLE `softwarelist`
  ADD PRIMARY KEY (`softwareId`);

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
  ADD PRIMARY KEY (`userName`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
