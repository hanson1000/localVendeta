-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 26 Jan 2017 pada 15.26
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `music`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bjcomusers`
--

CREATE TABLE `bjcomusers` (
  `id` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` varchar(15) NOT NULL,
  `fullname` varchar(25) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `bjcomusers`
--

INSERT INTO `bjcomusers` (`id`, `username`, `password`, `role`, `fullname`, `phone`, `address`, `email`) VALUES
('US001', 'admin', 'admin123', 'admin', 'Amazing Admin', '0987654321', 'jalan jalan ke kota kota', 'apaaja@apa.com'),
('US004', 'usertest', 'usertest123', 'member', 'asidbaisdbiasubid', '91623986129', 'asiupbdiuabsduaisa street', 'asibdaubs@asubdaiudbs.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bjcomusers`
--
ALTER TABLE `bjcomusers`
  ADD UNIQUE KEY `id` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
